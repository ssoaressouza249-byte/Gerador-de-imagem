package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ImageGeneratorRepository
import com.example.model.ChatMode
import com.example.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name and security guard match authentic package and label`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gerador de Imagem", appName)
    assertEquals("com.raylan.geradordeimagem", context.packageName)
    assertTrue(SecurityGuard.isAppAuthentic(context))
  }

  @Test
  fun `mode classifier routes photo edit, image gen, and idea chat accurately`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = ImageGeneratorRepository(context)

    assertEquals(ChatMode.PHOTO_EDIT, repo.classifyMode("adicione óculos escuro", true))
    assertEquals(ChatMode.IMAGE_GEN, repo.classifyMode("crie uma imagem de um leão dourado", false))
    assertEquals(ChatMode.IDEA_CHAT, repo.classifyMode("me dê ideias de prompts para fotos", false))
  }
}
