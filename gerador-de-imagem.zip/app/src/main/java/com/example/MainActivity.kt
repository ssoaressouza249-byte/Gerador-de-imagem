package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.SecurityGuard
import com.example.security.UnauthorizedModificationScreen
import com.example.ui.ChatViewModel
import com.example.ui.GeradorDeImagemScreen
import com.example.ui.theme.GeradorDeImagemTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle =
        SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
      navigationBarStyle =
        SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
    )

    val isAuthentic = SecurityGuard.isAppAuthentic(this)
    val currentPkg = packageName

    setContent {
      GeradorDeImagemTheme {
        if (!isAuthentic) {
          UnauthorizedModificationScreen(currentPackageName = currentPkg)
        } else {
          val chatViewModel: ChatViewModel = viewModel()
          GeradorDeImagemScreen(viewModel = chatViewModel)
        }
      }
    }
  }
}
