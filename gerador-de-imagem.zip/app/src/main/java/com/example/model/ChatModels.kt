package com.example.model

import android.net.Uri

enum class ResolutionPreset(
  val title: String,
  val dimensionsLabel: String,
  val width: Int,
  val height: Int,
) {
  UHD_4K(title = "4K", dimensionsLabel = "3840x2160", width = 3840, height = 2160),
  ULTRA_8K(title = "8K Ultra", dimensionsLabel = "4320x2430", width = 4320, height = 2430),
  SQUARE(title = "Quadrado", dimensionsLabel = "2048x2048", width = 2048, height = 2048),
  VERTICAL_WALLPAPER(
    title = "Vertical Wallpaper",
    dimensionsLabel = "2160x3840",
    width = 2160,
    height = 3840,
  ),
}

enum class ChatMode(val badgeLabel: String) {
  PHOTO_EDIT("Modo 1 • Edição de Foto"),
  IMAGE_GEN("Modo 2 • Criação 4K/8K"),
  IDEA_CHAT("Modo 3 • Ideias & Prompts"),
}

sealed interface ChatMessage {
  val id: String
  val timestamp: Long

  data class UserMessage(
    override val id: String,
    val text: String,
    val attachedImageUri: Uri? = null,
    override val timestamp: Long = System.currentTimeMillis(),
  ) : ChatMessage

  data class AiMessage(
    override val id: String,
    val text: String,
    val mode: ChatMode,
    val imageFilePath: String? = null,
    val resolution: ResolutionPreset? = null,
    val enhancedPrompt: String? = null,
    val seed: Long? = null,
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    override val timestamp: Long = System.currentTimeMillis(),
  ) : ChatMessage
}
