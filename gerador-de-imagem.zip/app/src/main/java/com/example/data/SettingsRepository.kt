package com.example.data

import android.content.Context

class SettingsRepository(context: Context) {
  private val prefs =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun getGeminiApiKey(): String {
    return runCatching { prefs.getString(KEY_GEMINI_API_KEY, "").orEmpty().trim() }.getOrDefault("")
  }

  fun saveGeminiApiKey(apiKey: String) {
    runCatching { prefs.edit().putString(KEY_GEMINI_API_KEY, apiKey.trim()).apply() }
  }

  companion object {
    private const val PREFS_NAME = "gerador_de_imagem_prefs"
    private const val KEY_GEMINI_API_KEY = "optional_gemini_api_key"
  }
}
