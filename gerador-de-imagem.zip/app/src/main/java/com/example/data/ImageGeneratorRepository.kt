package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.model.ChatMode
import com.example.model.ResolutionPreset
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class GenerationOutcome(
  val mode: ChatMode,
  val replyText: String,
  val imageFilePath: String? = null,
  val enhancedPrompt: String? = null,
  val seed: Long? = null,
)

class ImageGeneratorRepository(private val context: Context) {

  private val client: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(30, TimeUnit.SECONDS)
      .readTimeout(120, TimeUnit.SECONDS)
      .writeTimeout(60, TimeUnit.SECONDS)
      .retryOnConnectionFailure(true)
      .build()

  private val lastSeed = AtomicLong(0L)

  fun classifyMode(userPrompt: String, hasAttachment: Boolean): ChatMode {
    if (hasAttachment) return ChatMode.PHOTO_EDIT

    val normalized = userPrompt.trim().lowercase()
    if (normalized.isEmpty()) return ChatMode.IDEA_CHAT

    val ideaKeywords =
      listOf(
        "ideia",
        "ideias",
        "sugest",
        "sugir",
        "dica",
        "dicas",
        "melhorar prompt",
        "ajude a criar",
        "como criar",
        "como fazer",
        "como gerar",
        "quais estilos",
        "qual estilo",
        "o que é",
        "o que e",
        "dúvida",
        "duvida",
        "explic",
        "recomende",
      )

    if (ideaKeywords.any { normalized.contains(it) }) {
      return ChatMode.IDEA_CHAT
    }

    val creationKeywords =
      listOf(
        "crie",
        "criar",
        "gere",
        "gerar",
        "imagem de",
        "imagem ",
        "desenhe",
        "desenhar",
        "desenho",
        "foto de",
        "foto ",
        "ilustra",
        "wallpaper",
        "papel de parede",
        "pinte",
        "pintura",
        "arte de",
        "retrato",
        "paisagem",
        "render",
        "faça uma",
        "faca uma",
        "mostre uma",
        "create",
        "generate",
        "draw",
      )

    if (creationKeywords.any { normalized.contains(it) }) {
      return ChatMode.IMAGE_GEN
    }

    val conversationalKeywords =
      listOf("oi", "olá", "ola", "bom dia", "boa tarde", "boa noite", "tudo bem", "obrigad", "ajuda")
    if (normalized.endsWith("?") || conversationalKeywords.any { normalized.startsWith(it) }) {
      return ChatMode.IDEA_CHAT
    }

    return ChatMode.IMAGE_GEN
  }

  suspend fun processUserMessage(
    userPrompt: String,
    attachedImageUri: Uri?,
    resolution: ResolutionPreset,
    geminiApiKey: String,
  ): Result<GenerationOutcome> =
    withContext(Dispatchers.IO) {
      runCatching {
        val mode = classifyMode(userPrompt, attachedImageUri != null)
        when (mode) {
          ChatMode.PHOTO_EDIT ->
            handlePhotoEditMode(
              userDetails = userPrompt,
              imageUri = attachedImageUri!!,
              resolution = resolution,
              geminiApiKey = geminiApiKey,
            )
          ChatMode.IMAGE_GEN ->
            handleImageCreationMode(
              userPrompt = userPrompt,
              resolution = resolution,
              geminiApiKey = geminiApiKey,
            )
          ChatMode.IDEA_CHAT ->
            handleIdeaChatMode(userPrompt = userPrompt, geminiApiKey = geminiApiKey)
        }
      }
    }

  private fun handlePhotoEditMode(
    userDetails: String,
    imageUri: Uri,
    resolution: ResolutionPreset,
    geminiApiKey: String,
  ): GenerationOutcome {
    val cleanDetails =
      userDetails.trim().ifEmpty { "aprimorar iluminação cinematográfica e nitidez ultra realista" }

    val base64Image = encodeUriToJpegBase64(imageUri).getOrNull()

    val analysisSystemPrompt =
      "You are an expert AI photo-editing prompt engineer. Look closely at the attached photo and describe its main subject, person/object appearance, pose, clothing, framing, colors, and original setting in vivid English. Then seamlessly integrate ONLY the user's requested edits so the generated image keeps the original subject/scene identity while applying the requested details faithfully. Return ONLY the final English image generation prompt in one concise paragraph, with no markdown or explanations."

    val analysisUserPrompt = "User edit request: \"$cleanDetails\""

    var engineeredPrompt: String? = null

    if (geminiApiKey.isNotBlank() && base64Image != null) {
      engineeredPrompt =
        callGeminiRest(
            apiKey = geminiApiKey,
            systemInstruction = analysisSystemPrompt,
            userText = analysisUserPrompt,
            base64Jpeg = base64Image,
          )
          .getOrNull()
    }

    if (engineeredPrompt.isNullOrBlank() && base64Image != null) {
      engineeredPrompt =
        callPollinationsVisionText(
            systemInstruction = analysisSystemPrompt,
            userText = analysisUserPrompt,
            base64Jpeg = base64Image,
          )
          .getOrNull()
    }

    if (engineeredPrompt.isNullOrBlank()) {
      val translatedDetails =
        translateAndEnhancePrompt(cleanDetails, geminiApiKey).getOrNull() ?: cleanDetails
      val localVisualSummary = extractLocalVisualDescriptor(imageUri)
      engineeredPrompt = "$localVisualSummary, modified with: $translatedDetails"
    }

    val finalPrompt = appendUltraQualityTags(engineeredPrompt)
    val seed = nextUniqueSeed()
    val savedFile =
      downloadPollinationsImage(
          prompt = finalPrompt,
          resolution = resolution,
          seed = seed,
        )
        .getOrThrow()

    return GenerationOutcome(
      mode = ChatMode.PHOTO_EDIT,
      replyText =
        "Foto analisada e recriada em ${resolution.title} (${resolution.dimensionsLabel}) com os detalhes solicitados: \"$cleanDetails\".",
      imageFilePath = savedFile.absolutePath,
      enhancedPrompt = finalPrompt,
      seed = seed,
    )
  }

  private fun handleImageCreationMode(
    userPrompt: String,
    resolution: ResolutionPreset,
    geminiApiKey: String,
  ): GenerationOutcome {
    val basePrompt =
      translateAndEnhancePrompt(userPrompt, geminiApiKey).getOrNull() ?: userPrompt.trim()
    val finalPrompt = appendUltraQualityTags(basePrompt)
    val seed = nextUniqueSeed()

    val savedFile =
      downloadPollinationsImage(
          prompt = finalPrompt,
          resolution = resolution,
          seed = seed,
        )
        .getOrThrow()

    return GenerationOutcome(
      mode = ChatMode.IMAGE_GEN,
      replyText =
        "Imagem gerada em ${resolution.title} (${resolution.dimensionsLabel}) com seed única #$seed.",
      imageFilePath = savedFile.absolutePath,
      enhancedPrompt = finalPrompt,
      seed = seed,
    )
  }

  private fun handleIdeaChatMode(userPrompt: String, geminiApiKey: String): GenerationOutcome {
    val specialistSystemPrompt =
      "Você é um especialista criativo em geração e edição de imagens com IA, fotografia, iluminação, composição e engenharia de prompts. Responda em português do Brasil de forma clara, estruturada, criativa e prática, focando exclusivamente em temas de criação, ideias visuais, estilos artísticos, prompts e edição de imagens. Se o usuário perguntar algo fora desse tema, redirecione gentilmente para criação e edição de imagens."

    var answer: String? = null

    if (geminiApiKey.isNotBlank()) {
      answer =
        callGeminiRest(
            apiKey = geminiApiKey,
            systemInstruction = specialistSystemPrompt,
            userText = userPrompt,
            base64Jpeg = null,
          )
          .getOrNull()
    }

    if (answer.isNullOrBlank()) {
      answer =
        callPollinationsText(
            systemInstruction = specialistSystemPrompt,
            userText = userPrompt,
          )
          .getOrThrow()
    }

    return GenerationOutcome(
      mode = ChatMode.IDEA_CHAT,
      replyText = answer.trim(),
    )
  }

  private fun translateAndEnhancePrompt(userPrompt: String, geminiApiKey: String): Result<String> {
    return runCatching {
      val systemPrompt =
        "Translate the user's image request into a vivid, detailed English prompt optimized for FLUX image generation. Keep all specific objects, colors, lighting, camera angle, and mood faithful to the request. Output ONLY the English prompt without quotes, labels, or explanations."

      if (geminiApiKey.isNotBlank()) {
        val geminiResult =
          callGeminiRest(
              apiKey = geminiApiKey,
              systemInstruction = systemPrompt,
              userText = userPrompt,
              base64Jpeg = null,
            )
            .getOrNull()
        if (!geminiResult.isNullOrBlank()) {
          return@runCatching geminiResult.trim()
        }
      }

      val pollinationsText =
        callPollinationsText(systemInstruction = systemPrompt, userText = userPrompt).getOrNull()
      if (!pollinationsText.isNullOrBlank()) {
        pollinationsText.trim()
      } else {
        userPrompt.trim()
      }
    }
  }

  private fun appendUltraQualityTags(prompt: String): String {
    val cleaned = prompt.trim().trimEnd(',', '.')
    val ultraTags = "8k resolution, 4k uhd, photorealistic, masterpiece, sharp focus, ultra detailed"
    return if (cleaned.contains("8k resolution", ignoreCase = true)) {
      cleaned
    } else {
      "$cleaned, $ultraTags"
    }
  }

  private fun nextUniqueSeed(): Long {
    val now = System.currentTimeMillis()
    while (true) {
      val prev = lastSeed.get()
      val next = if (now > prev) now else prev + 1L
      if (lastSeed.compareAndSet(prev, next)) return next
    }
  }

  private fun downloadPollinationsImage(
    prompt: String,
    resolution: ResolutionPreset,
    seed: Long,
  ): Result<File> {
    return runCatching {
      val encodedPrompt = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")

      val candidates = buildList {
        add(Triple(resolution.width, resolution.height, "flux"))
        // Proportional high-res fallbacks in case upstream caps ultra-large dimensions
        when (resolution) {
          ResolutionPreset.UHD_4K,
          ResolutionPreset.ULTRA_8K -> {
            add(Triple(1920, 1080, "flux"))
            add(Triple(1280, 720, "turbo"))
          }
          ResolutionPreset.SQUARE -> {
            add(Triple(1024, 1024, "flux"))
            add(Triple(1024, 1024, "turbo"))
          }
          ResolutionPreset.VERTICAL_WALLPAPER -> {
            add(Triple(1080, 1920, "flux"))
            add(Triple(720, 1280, "turbo"))
          }
        }
      }

      var lastError: Throwable? = null
      for ((w, h, model) in candidates) {
        val url =
          "https://image.pollinations.ai/prompt/$encodedPrompt?width=$w&height=$h&model=$model&nologo=true&seed=$seed"
        val attempt = fetchAndValidateImage(url, seed)
        if (attempt.isSuccess) {
          return@runCatching attempt.getOrThrow()
        } else {
          lastError = attempt.exceptionOrNull()
        }
      }

      throw lastError ?: IllegalStateException("Não foi possível baixar a imagem gerada.")
    }
  }

  private fun fetchAndValidateImage(url: String, seed: Long): Result<File> {
    return runCatching {
      val request =
        Request.Builder()
          .url(url)
          .header("User-Agent", "GeradorDeImagem-Android/1.0")
          .header("Accept", "image/*")
          .get()
          .build()

      client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
          error("HTTP ${response.code} ao gerar imagem.")
        }
        val body = response.body ?: error("Resposta vazia do servidor de imagem.")
        val bytes = body.bytes()
        if (bytes.size < 1024) {
          error("Arquivo de imagem inválido ou incompleto.")
        }

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
          error("Os dados retornados não correspondem a uma imagem válida.")
        }

        val outputDir = File(context.filesDir, "generated_images")
        if (!outputDir.exists()) outputDir.mkdirs()
        val extension = if (bounds.outMimeType?.contains("png") == true) "png" else "jpg"
        val outFile = File(outputDir, "img_${seed}_${System.nanoTime()}.$extension")
        outFile.writeBytes(bytes)
        outFile
      }
    }
  }

  private fun callGeminiRest(
    apiKey: String,
    systemInstruction: String,
    userText: String,
    base64Jpeg: String?,
  ): Result<String> {
    return runCatching {
      val endpoint =
        "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent?key=$apiKey"

      val parts = JSONArray().apply {
        put(JSONObject().put("text", userText))
        if (!base64Jpeg.isNullOrBlank()) {
          put(
            JSONObject()
              .put(
                "inlineData",
                JSONObject().put("mimeType", "image/jpeg").put("data", base64Jpeg),
              )
          )
        }
      }

      val payload =
        JSONObject().apply {
          put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))),
          )
          put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
          put(
            "generationConfig",
            JSONObject().put("temperature", 0.7).put("maxOutputTokens", 1024),
          )
        }

      val request =
        Request.Builder()
          .url(endpoint)
          .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
          .build()

      client.newCall(request).execute().use { response ->
        val rawBody = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
          error("Gemini HTTP ${response.code}: $rawBody")
        }
        val json = JSONObject(rawBody)
        val candidates = json.optJSONArray("candidates") ?: error("Sem resposta do Gemini.")
        val first = candidates.optJSONObject(0) ?: error("Resposta vazia do Gemini.")
        val contentParts =
          first.optJSONObject("content")?.optJSONArray("parts") ?: error("Conteúdo ausente.")
        val text =
          (0 until contentParts.length())
            .mapNotNull { idx -> contentParts.optJSONObject(idx)?.optString("text") }
            .joinToString("\n")
            .trim()
        require(text.isNotEmpty()) { "Texto vazio retornado pelo Gemini." }
        text
      }
    }
  }

  private fun callPollinationsText(systemInstruction: String, userText: String): Result<String> {
    return runCatching {
      val payload =
        JSONObject().apply {
          put("model", "openai")
          put(
            "messages",
            JSONArray().apply {
              put(JSONObject().put("role", "system").put("content", systemInstruction))
              put(JSONObject().put("role", "user").put("content", userText))
            },
          )
          put("seed", nextUniqueSeed())
        }

      val postRequest =
        Request.Builder()
          .url("https://text.pollinations.ai/openai")
          .header("User-Agent", "GeradorDeImagem-Android/1.0")
          .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
          .build()

      val postResult =
        runCatching {
          client.newCall(postRequest).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val body = response.body?.string().orEmpty()
            val json = JSONObject(body)
            val choices = json.optJSONArray("choices") ?: error("Sem choices")
            val content =
              choices
                .optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content")
                .orEmpty()
                .trim()
            require(content.isNotEmpty()) { "Resposta vazia" }
            content
          }
        }

      if (postResult.isSuccess) return@runCatching postResult.getOrThrow()

      // Fallback GET endpoint on text.pollinations.ai
      val combinedPrompt = "$systemInstruction\n\nSolicitação: $userText"
      val encoded = URLEncoder.encode(combinedPrompt, "UTF-8").replace("+", "%20")
      val getRequest =
        Request.Builder()
          .url("https://text.pollinations.ai/$encoded?model=openai")
          .header("User-Agent", "GeradorDeImagem-Android/1.0")
          .get()
          .build()

      client.newCall(getRequest).execute().use { response ->
        if (!response.isSuccessful) error("Pollinations text HTTP ${response.code}")
        val text = response.body?.string().orEmpty().trim()
        require(text.isNotEmpty()) { "Resposta de texto vazia." }
        text
      }
    }
  }

  private fun callPollinationsVisionText(
    systemInstruction: String,
    userText: String,
    base64Jpeg: String,
  ): Result<String> {
    return runCatching {
      val contentArray =
        JSONArray().apply {
          put(JSONObject().put("type", "text").put("text", userText))
          put(
            JSONObject()
              .put("type", "image_url")
              .put(
                "image_url",
                JSONObject().put("url", "data:image/jpeg;base64,$base64Jpeg"),
              )
          )
        }

      val payload =
        JSONObject().apply {
          put("model", "openai")
          put(
            "messages",
            JSONArray().apply {
              put(JSONObject().put("role", "system").put("content", systemInstruction))
              put(JSONObject().put("role", "user").put("content", contentArray))
            },
          )
          put("seed", nextUniqueSeed())
        }

      val request =
        Request.Builder()
          .url("https://text.pollinations.ai/openai")
          .header("User-Agent", "GeradorDeImagem-Android/1.0")
          .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
          .build()

      client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("Vision HTTP ${response.code}")
        val body = response.body?.string().orEmpty()
        val json = JSONObject(body)
        val content =
          json
            .optJSONArray("choices")
            ?.optJSONObject(0)
            ?.optJSONObject("message")
            ?.optString("content")
            .orEmpty()
            .trim()
        require(content.isNotEmpty()) { "Análise de imagem vazia." }
        content
      }
    }
  }

  private fun encodeUriToJpegBase64(uri: Uri): Result<String> {
    return runCatching {
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, bounds)
      }

      var sampleSize = 1
      val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
      if (maxDim > 768) {
        while (maxDim / sampleSize > 768) {
          sampleSize *= 2
        }
      }

      val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
      val bitmap =
        context.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: error("Não foi possível ler a imagem selecionada.")

      try {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos)
        Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
      } finally {
        if (!bitmap.isRecycled) bitmap.recycle()
      }
    }
  }

  private fun extractLocalVisualDescriptor(uri: Uri): String {
    return runCatching {
        val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
        val bmp =
          context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, opts)
          } ?: return@runCatching "photographic scene"

        try {
          val orientation =
            when {
              bmp.width > bmp.height -> "wide horizontal composition"
              bmp.height > bmp.width -> "vertical portrait composition"
              else -> "square balanced composition"
            }
          var totalBrightness = 0L
          val sampleW = minOf(bmp.width, 16)
          val sampleH = minOf(bmp.height, 16)
          val stepX = maxOf(1, bmp.width / sampleW)
          val stepY = maxOf(1, bmp.height / sampleH)
          var count = 0
          for (y in 0 until bmp.height step stepY) {
            for (x in 0 until bmp.width step stepX) {
              val pixel = bmp.getPixel(x, y)
              val r = (pixel shr 16) and 0xFF
              val g = (pixel shr 8) and 0xFF
              val b = pixel and 0xFF
              totalBrightness += (r + g + b) / 3
              count++
            }
          }
          val avgLum = if (count > 0) totalBrightness / count else 128L
          val lighting =
            when {
              avgLum < 80 -> "moody low-light photography"
              avgLum > 175 -> "bright natural daylight photography"
              else -> "balanced studio and natural lighting"
            }
          "realistic photo with $orientation and $lighting"
        } finally {
          if (!bmp.isRecycled) bmp.recycle()
        }
      }
      .getOrDefault("realistic high-detail photograph")
  }

  companion object {
    private const val GEMINI_MODEL = "gemini-3.8-flash"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
  }
}
