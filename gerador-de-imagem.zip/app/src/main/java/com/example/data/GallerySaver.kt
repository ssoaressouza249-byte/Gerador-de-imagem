package com.example.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GallerySaver {
  private const val ALBUM_FOLDER = "GeradorDeImagem"

  suspend fun saveToGallery(
    context: Context,
    localFilePath: String,
    targetWidth: Int,
    targetHeight: Int,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val sourceFile = File(localFilePath)
        require(sourceFile.exists() && sourceFile.length() > 0L) {
          "Arquivo de imagem não encontrado."
        }

        val decodedBitmap =
          BitmapFactory.decodeFile(sourceFile.absolutePath)
            ?: error("Não foi possível decodificar a imagem.")

        val finalBitmap =
          if (decodedBitmap.width != targetWidth || decodedBitmap.height != targetHeight) {
            runCatching {
                Bitmap.createScaledBitmap(decodedBitmap, targetWidth, targetHeight, true)
              }
              .getOrElse { decodedBitmap }
          } else {
            decodedBitmap
          }

        val fileName = "GeradorDeImagem_${targetWidth}x${targetHeight}_${System.currentTimeMillis()}.jpg"

        try {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues =
              ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(
                  MediaStore.MediaColumns.RELATIVE_PATH,
                  "${Environment.DIRECTORY_PICTURES}/$ALBUM_FOLDER",
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
              }

            val resolver = context.contentResolver
            val imageUri =
              resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: error("Falha ao criar entrada no MediaStore.")

            runCatching {
                resolver.openOutputStream(imageUri)?.use { outputStream ->
                  val ok = finalBitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
                  if (!ok) error("Falha ao gravar bytes da imagem.")
                } ?: error("Não foi possível abrir fluxo de saída.")

                val publishValues =
                  ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(imageUri, publishValues, null, null)
              }
              .onFailure { throwable ->
                runCatching { resolver.delete(imageUri, null, null) }
                throw throwable
              }
          } else {
            val picturesDir =
              @Suppress("DEPRECATION")
              Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val targetDir = File(picturesDir, ALBUM_FOLDER)
            if (!targetDir.exists()) targetDir.mkdirs()
            val outFile = File(targetDir, fileName)
            FileOutputStream(outFile).use { out ->
              val ok = finalBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
              if (!ok) error("Falha ao gravar imagem na galeria.")
            }
            MediaScannerConnection.scanFile(
              context,
              arrayOf(outFile.absolutePath),
              arrayOf("image/jpeg"),
              null,
            )
          }
        } finally {
          if (finalBitmap !== decodedBitmap && !finalBitmap.isRecycled) {
            finalBitmap.recycle()
          }
          if (!decodedBitmap.isRecycled) {
            decodedBitmap.recycle()
          }
        }

        "Pictures/$ALBUM_FOLDER/$fileName"
      }
    }
}
