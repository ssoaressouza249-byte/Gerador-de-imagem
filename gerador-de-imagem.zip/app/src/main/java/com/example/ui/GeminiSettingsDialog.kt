package com.example.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AiBubbleBorder
import com.example.ui.theme.AiBubbleWhite
import com.example.ui.theme.TextBlack
import com.example.ui.theme.UserBubbleGreen

@Composable
fun GeminiSettingsDialog(
  currentKey: String,
  onSaveKey: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var keyInput by remember(currentKey) { mutableStateOf(currentKey) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = AiBubbleWhite,
    titleContentColor = TextBlack,
    textContentColor = TextBlack,
    shape = RoundedCornerShape(18.dp),
    title = {
      Text(
        text = "Configuração Opcional — Gemini REST",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Default,
        color = TextBlack,
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text =
            "O app já funciona 100% grátis e sem chave usando os endpoints da Pollinations. Se desejar, cole uma chave opcional da API REST do Gemini para usar exclusivamente o modelo gemini-3.8-flash na análise de fotos e ideias.",
          fontSize = 13.sp,
          lineHeight = 19.sp,
          fontFamily = FontFamily.Default,
          color = TextBlack,
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = keyInput,
          onValueChange = { keyInput = it },
          label = {
            Text(
              text = "Chave API Gemini (gemini-3.8-flash)",
              color = TextBlack,
              fontFamily = FontFamily.Default,
            )
          },
          placeholder = {
            Text(
              text = "AIza... (opcional)",
              color = TextBlack.copy(alpha = 0.55f),
              fontFamily = FontFamily.Monospace,
            )
          },
          singleLine = true,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextBlack,
              unfocusedTextColor = TextBlack,
              focusedBorderColor = UserBubbleGreen,
              unfocusedBorderColor = AiBubbleBorder,
              cursorColor = TextBlack,
            ),
          modifier = Modifier.fillMaxWidth().testTag("gemini_api_key_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onSaveKey(keyInput) },
        colors =
          ButtonDefaults.buttonColors(containerColor = UserBubbleGreen, contentColor = TextBlack),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("save_gemini_key_button"),
      ) {
        Text(
          text = "Salvar",
          fontWeight = FontWeight.Bold,
          color = TextBlack,
          fontFamily = FontFamily.Default,
        )
      }
    },
    dismissButton = {
      TextButton(onClick = { onSaveKey("") }, modifier = Modifier.testTag("clear_gemini_key_button")) {
        Text(text = "Usar só Pollinations", color = TextBlack, fontFamily = FontFamily.Default)
      }
    },
  )
}
