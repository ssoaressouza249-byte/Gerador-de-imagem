package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppBackground = Color(0xFFF2F4F7)
val TextBlack = Color(0xFF000000)
val UserBubbleGreen = Color(0xFF25D366)
val AiBubbleWhite = Color(0xFFFFFFFF)
val AiBubbleBorder = Color(0xFFD0D7DE)
val SelectedChipFill = Color(0xFFD1FADF)
val SelectedChipBorder = Color(0xFF16A34A)
val SubtleSurface = Color(0xFFE8ECF1)
val TamperRed = Color(0xFFB71C1C)
val WhitePure = Color(0xFFFFFFFF)
