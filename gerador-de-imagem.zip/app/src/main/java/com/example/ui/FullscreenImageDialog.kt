package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.ChatMessage
import com.example.ui.theme.AiBubbleBorder
import com.example.ui.theme.AiBubbleWhite
import com.example.ui.theme.TextBlack
import com.example.ui.theme.UserBubbleGreen
import java.io.File

@Composable
fun FullscreenImageDialog(
  message: ChatMessage.AiMessage,
  isSaving: Boolean,
  onSaveToGallery: () -> Unit,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  var scale by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    BackHandler(enabled = true) { onDismiss() }

    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Color(0xFF0E1116))
          .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
      val filePath = message.imageFilePath
      if (filePath != null) {
        AsyncImage(
          model =
            ImageRequest.Builder(context)
              .data(File(filePath))
              .crossfade(true)
              .build(),
          contentDescription = "Imagem em tela cheia",
          contentScale = ContentScale.Fit,
          modifier =
            Modifier.fillMaxSize()
              .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                  val updatedScale = (scale * zoom).coerceIn(1f, 4f)
                  scale = updatedScale
                  if (updatedScale > 1f) {
                    offsetX += pan.x
                    offsetY += pan.y
                  } else {
                    offsetX = 0f
                    offsetY = 0f
                  }
                }
              }
              .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                translationX = offsetX,
                translationY = offsetY,
              ),
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth().padding(16.dp).align(Alignment.TopCenter),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        message.resolution?.let { res ->
          Surface(
            color = AiBubbleWhite,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.border(1.dp, AiBubbleBorder, RoundedCornerShape(12.dp)),
          ) {
            Text(
              text = "${res.title} • ${res.dimensionsLabel}",
              color = TextBlack,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            )
          }
        } ?: Spacer(modifier = Modifier.width(1.dp))

        IconButton(
          onClick = onDismiss,
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .background(AiBubbleWhite)
              .border(1.dp, AiBubbleBorder, CircleShape)
              .testTag("close_fullscreen_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Fechar tela cheia",
            tint = TextBlack,
          )
        }
      }

      Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp).align(Alignment.BottomCenter),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Button(
          onClick = onSaveToGallery,
          enabled = !isSaving,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = UserBubbleGreen,
              contentColor = TextBlack,
              disabledContainerColor = UserBubbleGreen.copy(alpha = 0.6f),
              disabledContentColor = TextBlack,
            ),
          shape = RoundedCornerShape(14.dp),
          modifier =
            Modifier.fillMaxWidth().height(54.dp).testTag("fullscreen_save_gallery_button"),
        ) {
          if (isSaving) {
            CircularProgressIndicator(
              color = TextBlack,
              strokeWidth = 2.dp,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "SALVANDO NA GALERIA...",
              color = TextBlack,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Default,
            )
          } else {
            Icon(
              imageVector = Icons.Filled.Download,
              contentDescription = null,
              tint = TextBlack,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(id = R.string.save_to_gallery),
              color = TextBlack,
              fontSize = 15.sp,
              fontWeight = FontWeight.ExtraBold,
              fontFamily = FontFamily.Default,
            )
          }
        }
      }
    }
  }
}
