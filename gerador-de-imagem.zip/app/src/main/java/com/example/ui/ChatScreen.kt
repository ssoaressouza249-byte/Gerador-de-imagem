package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.ChatMessage
import com.example.model.ResolutionPreset
import com.example.ui.theme.AiBubbleBorder
import com.example.ui.theme.AiBubbleWhite
import com.example.ui.theme.AppBackground
import com.example.ui.theme.SelectedChipBorder
import com.example.ui.theme.SelectedChipFill
import com.example.ui.theme.SubtleSurface
import com.example.ui.theme.TextBlack
import com.example.ui.theme.UserBubbleGreen
import java.io.File

@Composable
fun GeradorDeImagemScreen(viewModel: ChatViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val listState = rememberLazyListState()

  val galleryPickerLauncher =
    rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
      runCatching { viewModel.onAttachmentSelected(uri) }
        .onFailure {
          Toast.makeText(context, "Não foi possível carregar a imagem selecionada.", Toast.LENGTH_SHORT)
            .show()
        }
    }

  LaunchedEffect(uiState.messages.size) {
    if (uiState.messages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.messages.lastIndex)
    }
  }

  Scaffold(
    containerColor = AppBackground,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      Column(
        modifier =
          Modifier.fillMaxWidth().background(AiBubbleWhite).statusBarsPadding()
      ) {
        HeaderBar(
          hasCustomApiKey = uiState.geminiApiKey.isNotBlank(),
          onOpenSettings = viewModel::openSettingsDialog,
        )
        ResolutionSelectorRow(
          selectedResolution = uiState.selectedResolution,
          onSelectResolution = viewModel::selectResolution,
        )
        HorizontalDivider(color = AiBubbleBorder, thickness = 1.dp)
      }
    },
    bottomBar = {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(AiBubbleWhite)
            .navigationBarsPadding()
            .imePadding()
      ) {
        HorizontalDivider(color = AiBubbleBorder, thickness = 1.dp)

        uiState.pendingAttachmentUri?.let { pendingUri ->
          PendingAttachmentBanner(
            uri = pendingUri,
            onClear = viewModel::clearAttachment,
          )
        }

        ChatComposerBar(
          inputText = uiState.inputText,
          hasAttachment = uiState.pendingAttachmentUri != null,
          isGenerating = uiState.isGenerating,
          onInputChange = viewModel::onInputChanged,
          onAttachClick = {
            runCatching { galleryPickerLauncher.launch("image/*") }
              .onFailure {
                Toast.makeText(
                    context,
                    "Não foi possível abrir a galeria.",
                    Toast.LENGTH_SHORT,
                  )
                  .show()
              }
          },
          onSendClick = viewModel::sendMessage,
        )

        OfficialFooterBar()
      }
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().background(AppBackground).padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        state = listState,
        modifier = Modifier.widthIn(max = 820.dp).fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        items(items = uiState.messages, key = { it.id }) { message ->
          when (message) {
            is ChatMessage.UserMessage -> UserChatBubble(message = message)
            is ChatMessage.AiMessage ->
              AiChatBubble(
                message = message,
                isSaving = uiState.isSavingToGallery,
                onImageClick = { viewModel.openFullscreen(message) },
                onSaveClick = { viewModel.saveImageToGallery(context, message) },
              )
          }
        }
      }
    }
  }

  if (uiState.isSettingsDialogOpen) {
    GeminiSettingsDialog(
      currentKey = uiState.geminiApiKey,
      onSaveKey = viewModel::saveGeminiApiKey,
      onDismiss = viewModel::dismissSettingsDialog,
    )
  }

  uiState.fullscreenMessage?.let { fullMsg ->
    FullscreenImageDialog(
      message = fullMsg,
      isSaving = uiState.isSavingToGallery,
      onSaveToGallery = { viewModel.saveImageToGallery(context, fullMsg) },
      onDismiss = viewModel::closeFullscreen,
    )
  }
}

@Composable
private fun HeaderBar(hasCustomApiKey: Boolean, onOpenSettings: () -> Unit) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Outlined.AutoAwesome,
          contentDescription = null,
          tint = TextBlack,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Gerador de Imagem",
          fontSize = 19.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.Default,
          color = TextBlack,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = stringResource(id = R.string.official_credits),
        fontSize = 11.sp,
        lineHeight = 14.sp,
        fontWeight = FontWeight.Medium,
        fontFamily = FontFamily.Default,
        color = TextBlack,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.testTag("header_credits_text"),
      )
    }

    Box(contentAlignment = Alignment.TopEnd) {
      IconButton(
        onClick = onOpenSettings,
        modifier = Modifier.size(48.dp).testTag("settings_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.Settings,
          contentDescription = "Configurar chave opcional do Gemini",
          tint = TextBlack,
          modifier = Modifier.size(22.dp),
        )
      }
      if (hasCustomApiKey) {
        Box(
          modifier =
            Modifier.padding(top = 10.dp, end = 10.dp)
              .size(8.dp)
              .clip(CircleShape)
              .background(UserBubbleGreen)
              .border(1.dp, TextBlack, CircleShape)
        )
      }
    }
  }
}

@Composable
private fun ResolutionSelectorRow(
  selectedResolution: ResolutionPreset,
  onSelectResolution: (ResolutionPreset) -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    ResolutionPreset.entries.forEach { preset ->
      val isSelected = preset == selectedResolution
      val bgColor = if (isSelected) SelectedChipFill else AiBubbleWhite
      val borderColor = if (isSelected) SelectedChipBorder else AiBubbleBorder
      val borderWidth = if (isSelected) 1.5.dp else 1.dp

      Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier =
          Modifier.height(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(borderWidth, borderColor, RoundedCornerShape(12.dp))
            .clickable { onSelectResolution(preset) }
            .testTag("resolution_chip_${preset.name}"),
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalArrangement = Arrangement.Center,
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Text(
            text = preset.title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Default,
            color = TextBlack,
            maxLines = 1,
          )
          Text(
            text = preset.dimensionsLabel,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            color = TextBlack,
            maxLines = 1,
          )
        }
      }
    }
  }
}

@Composable
private fun UserChatBubble(message: ChatMessage.UserMessage) {
  val context = LocalContext.current
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
    Box(
      modifier =
        Modifier.widthIn(max = 310.dp)
          .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp))
          .background(UserBubbleGreen)
          .padding(12.dp)
    ) {
      Column {
        message.attachedImageUri?.let { uri ->
          AsyncImage(
            model = ImageRequest.Builder(context).data(uri).crossfade(true).build(),
            contentDescription = "Foto enviada da galeria",
            contentScale = ContentScale.Crop,
            modifier =
              Modifier.fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, TextBlack.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
          )
          Spacer(modifier = Modifier.height(8.dp))
        }

        Text(
          text = message.text,
          color = TextBlack,
          fontSize = 15.sp,
          lineHeight = 21.sp,
          fontWeight = FontWeight.Normal,
          fontFamily = FontFamily.Default,
        )
      }
    }
  }
}

@Composable
private fun AiChatBubble(
  message: ChatMessage.AiMessage,
  isSaving: Boolean,
  onImageClick: () -> Unit,
  onSaveClick: () -> Unit,
) {
  val context = LocalContext.current

  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
    Box(
      modifier =
        Modifier.widthIn(max = 340.dp)
          .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp))
          .background(AiBubbleWhite)
          .border(
            1.dp,
            AiBubbleBorder,
            RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp),
          )
          .padding(12.dp)
    ) {
      Column {
        Surface(
          color = SubtleSurface,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.padding(bottom = 8.dp),
        ) {
          Text(
            text = message.mode.badgeLabel,
            color = TextBlack,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }

        if (message.isLoading) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 4.dp),
          ) {
            CircularProgressIndicator(
              color = TextBlack,
              strokeWidth = 2.5.dp,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = message.text,
              color = TextBlack,
              fontSize = 14.sp,
              fontFamily = FontFamily.Default,
            )
          }
        } else {
          Text(
            text = message.text,
            color = TextBlack,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            fontFamily = FontFamily.Default,
          )

          val imagePath = message.imageFilePath
          if (imagePath != null) {
            Spacer(modifier = Modifier.height(10.dp))

            val aspect =
              when (message.resolution) {
                ResolutionPreset.SQUARE -> 1f
                ResolutionPreset.VERTICAL_WALLPAPER -> 9f / 16f
                else -> 16f / 9f
              }

            AsyncImage(
              model = ImageRequest.Builder(context).data(File(imagePath)).crossfade(true).build(),
              contentDescription = "Imagem gerada — toque para abrir em tela cheia",
              contentScale = ContentScale.Crop,
              modifier =
                Modifier.fillMaxWidth()
                  .aspectRatio(aspect)
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, AiBubbleBorder, RoundedCornerShape(12.dp))
                  .clickable(onClick = onImageClick)
                  .testTag("generated_image_${message.id}"),
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = "Toque na imagem para abrir em tela cheia",
              color = TextBlack,
              fontSize = 11.sp,
              fontFamily = FontFamily.Default,
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
              onClick = onSaveClick,
              enabled = !isSaving,
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = UserBubbleGreen,
                  contentColor = TextBlack,
                  disabledContainerColor = UserBubbleGreen.copy(alpha = 0.6f),
                  disabledContentColor = TextBlack,
                ),
              shape = RoundedCornerShape(10.dp),
              modifier =
                Modifier.fillMaxWidth().height(48.dp).testTag("chat_save_gallery_${message.id}"),
            ) {
              Icon(
                imageVector = Icons.Filled.Download,
                contentDescription = null,
                tint = TextBlack,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = stringResource(id = R.string.save_to_gallery),
                color = TextBlack,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Default,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PendingAttachmentBanner(uri: Uri, onClear: () -> Unit) {
  val context = LocalContext.current
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .background(SelectedChipFill)
        .padding(horizontal = 12.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    AsyncImage(
      model = ImageRequest.Builder(context).data(uri).crossfade(true).build(),
      contentDescription = "Miniatura anexada",
      contentScale = ContentScale.Crop,
      modifier =
        Modifier.size(44.dp)
          .clip(RoundedCornerShape(8.dp))
          .border(1.dp, SelectedChipBorder, RoundedCornerShape(8.dp)),
    )
    Spacer(modifier = Modifier.width(10.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = "Modo 1 Ativo • Foto da Galeria",
        color = TextBlack,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Default,
      )
      Text(
        text = "Escreva apenas os detalhes para adicionar ou alterar.",
        color = TextBlack,
        fontSize = 11.sp,
        fontFamily = FontFamily.Default,
      )
    }
    IconButton(
      onClick = onClear,
      modifier = Modifier.size(48.dp).testTag("clear_attachment_button"),
    ) {
      Icon(
        imageVector = Icons.Filled.Close,
        contentDescription = "Remover foto anexada",
        tint = TextBlack,
      )
    }
  }
}

@Composable
private fun ChatComposerBar(
  inputText: String,
  hasAttachment: Boolean,
  isGenerating: Boolean,
  onInputChange: (String) -> Unit,
  onAttachClick: () -> Unit,
  onSendClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    IconButton(
      onClick = onAttachClick,
      enabled = !isGenerating,
      modifier = Modifier.size(48.dp).testTag("attach_image_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.AddPhotoAlternate,
        contentDescription = "Anexar foto da galeria",
        tint = TextBlack,
        modifier = Modifier.size(26.dp),
      )
    }

    OutlinedTextField(
      value = inputText,
      onValueChange = onInputChange,
      placeholder = {
        Text(
          text =
            if (hasAttachment) {
              "Ex: adicione óculos escuro e céu estrelado"
            } else {
              "Peça imagem 4K/8K, edite foto ou tire dúvidas..."
            },
          color = TextBlack.copy(alpha = 0.55f),
          fontSize = 14.sp,
          fontFamily = FontFamily.Default,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      },
      singleLine = false,
      maxLines = 4,
      keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
      keyboardActions = KeyboardActions(onSend = { onSendClick() }),
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedTextColor = TextBlack,
          unfocusedTextColor = TextBlack,
          focusedContainerColor = AppBackground,
          unfocusedContainerColor = AppBackground,
          focusedBorderColor = SelectedChipBorder,
          unfocusedBorderColor = AiBubbleBorder,
          cursorColor = TextBlack,
        ),
      shape = RoundedCornerShape(22.dp),
      modifier = Modifier.weight(1f).testTag("prompt_input_field"),
    )

    Spacer(modifier = Modifier.width(6.dp))

    IconButton(
      onClick = onSendClick,
      enabled = !isGenerating && (inputText.isNotBlank() || hasAttachment),
      modifier =
        Modifier.size(48.dp)
          .clip(CircleShape)
          .background(
            if (!isGenerating && (inputText.isNotBlank() || hasAttachment)) {
              UserBubbleGreen
            } else {
              SubtleSurface
            }
          )
          .testTag("send_message_button"),
    ) {
      Icon(
        imageVector = Icons.AutoMirrored.Filled.Send,
        contentDescription = "Enviar mensagem",
        tint = TextBlack,
      )
    }
  }
}

@Composable
private fun OfficialFooterBar() {
  Box(
    modifier =
      Modifier.fillMaxWidth()
        .background(AppBackground)
        .border(0.5.dp, AiBubbleBorder)
        .padding(horizontal = 12.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = stringResource(id = R.string.official_credits),
      color = TextBlack,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold,
      fontFamily = FontFamily.Default,
      textAlign = TextAlign.Center,
      modifier = Modifier.testTag("footer_credits_text"),
    )
  }
}
