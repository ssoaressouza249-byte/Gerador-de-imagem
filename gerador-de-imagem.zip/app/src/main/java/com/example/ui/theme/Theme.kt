package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val AppLightColorScheme =
  lightColorScheme(
    primary = UserBubbleGreen,
    onPrimary = TextBlack,
    primaryContainer = SelectedChipFill,
    onPrimaryContainer = TextBlack,
    secondary = SelectedChipBorder,
    onSecondary = TextBlack,
    secondaryContainer = SubtleSurface,
    onSecondaryContainer = TextBlack,
    background = AppBackground,
    onBackground = TextBlack,
    surface = AiBubbleWhite,
    onSurface = TextBlack,
    surfaceVariant = SubtleSurface,
    onSurfaceVariant = TextBlack,
    outline = AiBubbleBorder,
    error = TamperRed,
    onError = WhitePure,
  )

@Composable
fun GeradorDeImagemTheme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = AppLightColorScheme, typography = Typography, content = content)
}
