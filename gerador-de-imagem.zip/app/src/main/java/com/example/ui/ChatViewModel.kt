package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GallerySaver
import com.example.data.ImageGeneratorRepository
import com.example.data.SettingsRepository
import com.example.model.ChatMessage
import com.example.model.ChatMode
import com.example.model.ResolutionPreset
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
  val messages: List<ChatMessage> = emptyList(),
  val selectedResolution: ResolutionPreset = ResolutionPreset.UHD_4K,
  val pendingAttachmentUri: Uri? = null,
  val inputText: String = "",
  val isGenerating: Boolean = false,
  val geminiApiKey: String = "",
  val isSettingsDialogOpen: Boolean = false,
  val fullscreenMessage: ChatMessage.AiMessage? = null,
  val isSavingToGallery: Boolean = false,
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = ImageGeneratorRepository(application.applicationContext)
  private val settingsRepository = SettingsRepository(application.applicationContext)

  private val _uiState =
    MutableStateFlow(
      ChatUiState(
        messages = listOf(createWelcomeMessage()),
        geminiApiKey = settingsRepository.getGeminiApiKey(),
      )
    )
  val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

  private fun createWelcomeMessage(): ChatMessage.AiMessage {
    return ChatMessage.AiMessage(
      id = "welcome_msg",
      mode = ChatMode.IDEA_CHAT,
      text =
        "Bem-vindo ao Gerador de Imagem! Pronto para criar e editar imediatamente (sem precisar de chave API):\n\n" +
          "• Modo 1 (Foto + Detalhes): toque no ícone de imagem ao lado do campo de texto, escolha uma foto da galeria e escreva apenas o que deseja adicionar ou alterar.\n" +
          "• Modo 2 (Criação 4K/8K): peça qualquer imagem (ex: \"crie um carro esportivo cyberpunk na chuva\") e escolha a resolução no topo.\n" +
          "• Modo 3 (Ideias & Dúvidas): peça sugestões de prompts, estilos ou tire dúvidas sobre criação de imagens.",
    )
  }

  fun selectResolution(preset: ResolutionPreset) {
    _uiState.update { it.copy(selectedResolution = preset) }
  }

  fun onInputChanged(text: String) {
    _uiState.update { it.copy(inputText = text) }
  }

  fun onAttachmentSelected(uri: Uri?) {
    if (uri != null) {
      _uiState.update { it.copy(pendingAttachmentUri = uri) }
    }
  }

  fun clearAttachment() {
    _uiState.update { it.copy(pendingAttachmentUri = null) }
  }

  fun openSettingsDialog() {
    _uiState.update { it.copy(isSettingsDialogOpen = true) }
  }

  fun dismissSettingsDialog() {
    _uiState.update { it.copy(isSettingsDialogOpen = false) }
  }

  fun saveGeminiApiKey(newKey: String) {
    val trimmed = newKey.trim()
    settingsRepository.saveGeminiApiKey(trimmed)
    _uiState.update { it.copy(geminiApiKey = trimmed, isSettingsDialogOpen = false) }
  }

  fun openFullscreen(message: ChatMessage.AiMessage) {
    if (!message.imageFilePath.isNullOrBlank()) {
      _uiState.update { it.copy(fullscreenMessage = message) }
    }
  }

  fun closeFullscreen() {
    _uiState.update { it.copy(fullscreenMessage = null) }
  }

  fun sendMessage() {
    val currentState = _uiState.value
    if (currentState.isGenerating) return

    val promptText = currentState.inputText.trim()
    val attachmentUri = currentState.pendingAttachmentUri
    if (promptText.isEmpty() && attachmentUri == null) return

    val effectivePrompt =
      if (promptText.isEmpty() && attachmentUri != null) {
        "aprimorar detalhes, nitidez e iluminação cinematográfica"
      } else {
        promptText
      }

    val detectedMode = repository.classifyMode(effectivePrompt, attachmentUri != null)
    val selectedResolution = currentState.selectedResolution
    val apiKey = currentState.geminiApiKey

    val userMsg =
      ChatMessage.UserMessage(
        id = UUID.randomUUID().toString(),
        text = effectivePrompt,
        attachedImageUri = attachmentUri,
      )

    val loadingMsgId = UUID.randomUUID().toString()
    val loadingText =
      when (detectedMode) {
        ChatMode.PHOTO_EDIT -> "Analisando sua foto e aplicando os detalhes solicitados..."
        ChatMode.IMAGE_GEN ->
          "Gerando imagem em ${selectedResolution.title} (${selectedResolution.dimensionsLabel})..."
        ChatMode.IDEA_CHAT -> "Elaborando ideias e recomendações..."
      }

    val loadingMsg =
      ChatMessage.AiMessage(
        id = loadingMsgId,
        text = loadingText,
        mode = detectedMode,
        resolution = if (detectedMode != ChatMode.IDEA_CHAT) selectedResolution else null,
        isLoading = true,
      )

    _uiState.update {
      it.copy(
        messages = it.messages + userMsg + loadingMsg,
        inputText = "",
        pendingAttachmentUri = null,
        isGenerating = true,
      )
    }

    viewModelScope.launch {
      val result =
        runCatching {
            repository.processUserMessage(
              userPrompt = effectivePrompt,
              attachedImageUri = attachmentUri,
              resolution = selectedResolution,
              geminiApiKey = apiKey,
            )
          }
          .fold(onSuccess = { it }, onFailure = { Result.failure(it) })

      _uiState.update { state ->
        val updatedMessages =
          state.messages.map { msg ->
            if (msg.id == loadingMsgId) {
              result.fold(
                onSuccess = { outcome ->
                  ChatMessage.AiMessage(
                    id = loadingMsgId,
                    text = outcome.replyText,
                    mode = outcome.mode,
                    imageFilePath = outcome.imageFilePath,
                    resolution =
                      if (outcome.imageFilePath != null) selectedResolution else null,
                    enhancedPrompt = outcome.enhancedPrompt,
                    seed = outcome.seed,
                    isLoading = false,
                    isError = false,
                  )
                },
                onFailure = { error ->
                  ChatMessage.AiMessage(
                    id = loadingMsgId,
                    text =
                      "Não foi possível concluir agora (${error.localizedMessage ?: "erro de conexão"}). Verifique sua internet e tente novamente.",
                    mode = detectedMode,
                    isLoading = false,
                    isError = true,
                  )
                },
              )
            } else {
              msg
            }
          }
        state.copy(messages = updatedMessages, isGenerating = false)
      }
    }
  }

  fun saveImageToGallery(context: Context, message: ChatMessage.AiMessage) {
    val filePath = message.imageFilePath ?: return
    val resolution = message.resolution ?: _uiState.value.selectedResolution

    if (_uiState.value.isSavingToGallery) return
    _uiState.update { it.copy(isSavingToGallery = true) }

    viewModelScope.launch {
      val result =
        runCatching {
            GallerySaver.saveToGallery(
              context = context.applicationContext,
              localFilePath = filePath,
              targetWidth = resolution.width,
              targetHeight = resolution.height,
            )
          }
          .fold(onSuccess = { it }, onFailure = { Result.failure(it) })

      _uiState.update { it.copy(isSavingToGallery = false) }

      result
        .onSuccess { savedRelativePath ->
          runCatching {
            Toast.makeText(
                context,
                "Salvo em ${resolution.title} na pasta $savedRelativePath",
                Toast.LENGTH_LONG,
              )
              .show()
          }
        }
        .onFailure { err ->
          runCatching {
            Toast.makeText(
                context,
                "Erro ao salvar na galeria: ${err.localizedMessage ?: "tente novamente"}",
                Toast.LENGTH_LONG,
              )
              .show()
          }
        }
    }
  }
}
