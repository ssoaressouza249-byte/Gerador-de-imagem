package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.TamperRed
import com.example.ui.theme.TextBlack
import com.example.ui.theme.WhitePure

object SecurityGuard {
  const val EXPECTED_PACKAGE_NAME = "com.raylan.geradordeimagem"
  const val EXPECTED_APP_LABEL_FRAGMENT = "Gerador de Imagem"

  /**
   * Verifies at startup whether packageName and application label remain authentic. Certificate
   * signatures are intentionally not checked so GitHub Actions debug builds are unaffected.
   */
  fun isAppAuthentic(context: Context): Boolean {
    return runCatching {
        val currentPackage = context.packageName
        val currentLabel = context.applicationInfo.loadLabel(context.packageManager).toString()
        currentPackage == EXPECTED_PACKAGE_NAME &&
          currentLabel.contains(EXPECTED_APP_LABEL_FRAGMENT)
      }
      .getOrDefault(false)
  }
}

@Composable
fun UnauthorizedModificationScreen(currentPackageName: String) {
  val context = LocalContext.current

  BackHandler(enabled = true) {
    // Intentionally blocked when unauthorized modification is detected.
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(TamperRed)
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = "Alerta de modificação não autorizada",
        tint = WhitePure,
        modifier = Modifier.size(72.dp),
      )

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = stringResource(id = R.string.tamper_warning),
        color = WhitePure,
        fontSize = 18.sp,
        lineHeight = 26.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Default,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("tamper_warning_text"),
      )

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = "Pacote detectado: $currentPackageName",
        color = WhitePure.copy(alpha = 0.9f),
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(32.dp))

      Button(
        onClick = {
          runCatching {
              val uninstallIntent =
                Intent(Intent.ACTION_DELETE, Uri.parse("package:$currentPackageName")).apply {
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
              context.startActivity(uninstallIntent)
            }
            .onFailure {
              Toast.makeText(
                  context,
                  "Não foi possível abrir o desinstalador do sistema.",
                  Toast.LENGTH_SHORT,
                )
                .show()
            }
        },
        colors =
          ButtonDefaults.buttonColors(containerColor = WhitePure, contentColor = TextBlack),
        shape = RoundedCornerShape(12.dp),
        modifier =
          Modifier.fillMaxWidth().height(54.dp).testTag("uninstall_now_button"),
      ) {
        Text(
          text = stringResource(id = R.string.uninstall_now),
          fontSize = 16.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.Default,
          color = TextBlack,
        )
      }
    }
  }
}
